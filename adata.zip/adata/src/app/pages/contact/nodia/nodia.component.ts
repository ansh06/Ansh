import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nodia',
  templateUrl: './nodia.component.html',
  styleUrls: ['./nodia.component.css']
})
export class NodiaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
