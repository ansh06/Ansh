import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AttrDirective } from './directive/attr.directive';
import { LimitPipe } from './pipes/limit.pipe';
import { EmpComponent } from './pages/emp/emp.component';
import { ReactiveComponent } from './pages/reactive/reactive.component';
import { HomeComponent } from './pages/home/home.component';
import { AboutComponent } from './pages/about/about.component';
import { ContactComponent } from './pages/contact/contact.component';
import { CategoryComponent } from './pages/category/category.component';
import { NoidaComponent } from './pages/contact/noida/noida.component';
import { DelhiComponent } from './pages/contact/delhi/delhi.component';

@NgModule({
  declarations: [
    AppComponent,
    AttrDirective,
    LimitPipe,
    EmpComponent,
    ReactiveComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    CategoryComponent,
    NoidaComponent,
    DelhiComponent //componet , pipes , directive
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule// modules 
  ],
  providers: [],//services
  bootstrap: [AppComponent]
})
export class AppModule { }
