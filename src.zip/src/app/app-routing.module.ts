import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { AboutComponent } from './pages/about/about.component';
import { ContactComponent } from './pages/contact/contact.component';
import { CategoryComponent } from './pages/category/category.component';
import { NoidaComponent } from './pages/contact/noida/noida.component';
import { DelhiComponent } from './pages/contact/delhi/delhi.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'contact',component:ContactComponent,children:[
    {path:'noida',component:NoidaComponent},
    {path:'delhi',component:DelhiComponent}
  ]},
  {path:'category/:cat',component:CategoryComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
