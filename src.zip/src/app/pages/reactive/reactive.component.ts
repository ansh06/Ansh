import { Component, OnInit } from '@angular/core';
import { FormGroup , FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {
  myForm:FormGroup;
  constructor(private fb:FormBuilder) {
    this.myForm=this.fb.group(
      {
        'name':['',Validators.required],
        'age':['',Validators.required]
      }
    )
   }
  xyz()
  {
    let formData=this.myForm.getRawValue();
    console.log(formData)
  }
  ngOnInit() {
  }

}
